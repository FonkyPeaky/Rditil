﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Rditil.Services;
using System;
using System.Threading.Tasks;

namespace Rditil.ViewModels
{
    public partial class LoginViewModel : ObservableObject
    {
        private readonly IUserService _userService;
        private readonly IAppState _appState;

        public event Action? LoginSucceeded;

        [ObservableProperty] private string email = "";
        [ObservableProperty] private string password = "";
        [ObservableProperty] private string errorMessage = "";

        public LoginViewModel(IUserService userService, IAppState appState)
        {
            _userService = userService;
            _appState = appState;
        }

        [RelayCommand]
        private async Task LoginAsync()
        {
            ErrorMessage = "";

            var user = await _userService.GetByEmailAsync(Email);

            if (user != null && BCrypt.Net.BCrypt.Verify(Password, user.PasswordHash))
            {
                _appState.CurrentUser = user;
                _appState.ManagerEmail = user.EmailNPlus1;

                LoginSucceeded?.Invoke();
                return;
            }

            ErrorMessage = "Identifiants invalides";
        }

    }
}
