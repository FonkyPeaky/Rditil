using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Rditil.Models;
using Rditil.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rditil.ViewModels
{
    public partial class EndPageViewModel : ObservableObject, INavigable
    {
        private readonly IAppState _appState;
        private readonly IEmailService _emailService;

        // Résumé (lecture seule côté UI)
        [ObservableProperty] private string userFullName = "";
        [ObservableProperty] private string userEmail = "";
        [ObservableProperty] private string managerEmail = "";
        [ObservableProperty] private string durationText = "00:00:00";
        [ObservableProperty] private string scoreText = "0/0";

        // Aperçu mail (lecture seule côté UI)
        [ObservableProperty] private string mailBody = "";

        // Statut
        [ObservableProperty] private bool isSending;
        [ObservableProperty] private string statusText = "";

        public ObservableCollection<ExamReportRow> ReportRows { get; } = new();

        public IAsyncRelayCommand SendAndCloseCommand { get; }
        [ObservableProperty] private bool showConfirmationPopup;
        [ObservableProperty] private int closeCountdown = 5;


        public EndPageViewModel(IAppState appState, IEmailService emailService)
        {
            _appState = appState;
            _emailService = emailService;

            SendAndCloseCommand = new AsyncRelayCommand(SendAndCloseAsync, () => !IsSending);

            LoadFromState();
        }

        public void OnNavigatedTo(System.Collections.Generic.Dictionary<string, object?>? parameters)
        {
            LoadFromState();
        }

        private void LoadFromState()
        {
            var r = _appState.LastExamResult;
            var rows = _appState.LastExamRows;

            // Valeurs issues du state (donc DB)
            UserFullName = r?.UserFullName ?? "";
            UserEmail = r?.UserEmail ?? "";
            // ✅ email N+1 par défaut depuis la DB/state, pas modifiable
            ManagerEmail = _appState.ManagerEmail
                           ?? r?.ManagerEmail
                           ?? "";

            DurationText = (r?.Duration ?? TimeSpan.Zero).ToString(@"hh\:mm\:ss");
            ScoreText = r == null ? "0/0" : $"{r.Score}/{r.Total}";

            ReportRows.Clear();
            if (rows != null)
            {
                foreach (var row in rows)
                    ReportRows.Add(row);
            }

            MailBody = BuildPlainPreviewBody();
            StatusText = "";
        }

        private string BuildPlainPreviewBody()
        {
            var sb = new StringBuilder();

            sb.AppendLine($"Utilisateur : {UserFullName}");
            sb.AppendLine($"Email : {UserEmail}");
            sb.AppendLine($"Score : {ScoreText}");
            sb.AppendLine($"Durée : {DurationText}");
            sb.AppendLine();
            sb.AppendLine("Détails :");

            foreach (var r in ReportRows.Take(15))
            {
                var ok = r.IsCorrect ? "OK" : "FAUX";
                sb.AppendLine($"- {r.Index}. {Trim(r.Enonce, 70)} => {Trim(r.ChosenText, 45)} ({ok})");
            }

            if (ReportRows.Count > 15)
                sb.AppendLine($"... ({ReportRows.Count - 15} lignes de plus)");

            return sb.ToString();

            static string Trim(string s, int max)
                => string.IsNullOrWhiteSpace(s) ? "" : (s.Length <= max ? s : s.Substring(0, max) + "…");
        }

        private async Task SendAndCloseAsync()
        {
            try
            {
                IsSending = true;
                SendAndCloseCommand.NotifyCanExecuteChanged();
                StatusText = "Envoi en cours...";

                var to = ManagerEmail?.Trim();
                if (string.IsNullOrWhiteSpace(to))
                    throw new InvalidOperationException("Email du N+1 manquant.");

                var r = _appState.LastExamResult;
                if (r == null)
                    throw new InvalidOperationException("Aucun résultat d'examen.");

                var subject = $"RDITIL — Résultats {UserFullName} ({r.Score}/{r.Total})";

                await _emailService.SendExamReportAsync(
                    to: to,
                    cc: null,
                    subject: subject,
                    userFullName: UserFullName,
                    score: r.Score,
                    total: r.Total,
                    duration: r.Duration,
                    rows: ReportRows.ToList()
                );

                // ✅ Affiche le popup
                StatusText = "Email envoyé avec succès ✅";
                ShowConfirmationPopup = true;
                CloseCountdown = 5;

                // ⏳ compte à rebours
                while (CloseCountdown > 0)
                {
                    await Task.Delay(1000);
                    CloseCountdown--;
                }

                App.Current.Shutdown();
            }
            catch (Exception ex)
            {
                StatusText = $"Erreur : {ex.Message}";
            }
            finally
            {
                IsSending = false;
                SendAndCloseCommand.NotifyCanExecuteChanged();
            }
        }

    }
}
