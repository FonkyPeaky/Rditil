using System.Windows.Input;
using Rditil.Services;

namespace Rditil.ViewModels;

public class WelcomeViewModel : ViewModelBase
{
    private readonly INavigationService _navigationService;
    private readonly IAppState _appState;

    public ICommand StartExamCommand { get; }

    public string UserFullName
    {
        get
        {
            var u = _appState.CurrentUser;
            if (u == null) return "";
            return $"{u.Prenom} {u.Nom}".Trim();
        }
    }

    public WelcomeViewModel(INavigationService navigationService, IAppState appState)
    {
        _navigationService = navigationService;
        _appState = appState;
        StartExamCommand = new RelayCommand(StartExam);
    }

    private void StartExam()
    {
        _navigationService.NavigateTo<ExamViewModel>();
    }
}
