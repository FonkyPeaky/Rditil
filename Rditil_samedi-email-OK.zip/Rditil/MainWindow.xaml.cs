﻿using System.Windows;
using Rditil.Services;

namespace Rditil
{
    public partial class MainWindow : Window
    {
        public MainWindow(INavigationService navigation)
        {
            InitializeComponent();
            navigation.Initialize(MainFrame); // ✅ le frame est prêt AVANT toute navigation
        }
    }
}
