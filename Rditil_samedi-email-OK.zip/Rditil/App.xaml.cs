﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Rditil.Data;
using Rditil.Services;
using Rditil.ViewModels;
using Rditil.Views;
using System.Windows;

namespace Rditil
{
    public partial class App : Application
    {
        public static IHost AppHost { get; private set; } = null!;

        public App()
        {
            AppHost = Host.CreateDefaultBuilder()
                .ConfigureServices((context, services) =>
                {
                    var config = context.Configuration;

                    services.AddDbContextFactory<AppDbContext>(options =>
                        options.UseNpgsql(config.GetConnectionString("DefaultConnection")));

                    // Services
                    services.AddSingleton<INavigationService, NavigationService>();
                    services.AddSingleton<IAppState, AppState>();
                    services.AddSingleton<IUserService, UserService>();

                    services.Configure<SmtpSettings>(context.Configuration.GetSection("Smtp"));
                    services.AddSingleton<IEmailService, EmailService>();

                    // ViewModels
                    services.AddTransient<LoginViewModel>();
                    services.AddTransient<WelcomeViewModel>();
                    services.AddTransient<ExamViewModel>();
                    services.AddTransient<EndPageViewModel>();

                    // Pages
                    services.AddTransient<WelcomePage>();
                    services.AddTransient<QuestionPage>();
                    services.AddTransient<EndPage>();

                    // Windows
                    services.AddTransient<LoginWindow>();
                    services.AddSingleton<MainWindow>();

                    services.AddSingleton<ISmtpSettingsProvider, DbSmtpSettingsProvider>();
                    services.AddSingleton<IEmailService, EmailService>();

                    // garde aussi le Configure<SmtpSettings> si tu veux le fallback JSON
                    services.Configure<SmtpSettings>(context.Configuration.GetSection("Smtp"));

                })
                .Build();
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Important : si la fenêtre de login se ferme, ne pas fermer l'app
            ShutdownMode = ShutdownMode.OnExplicitShutdown;

            await AppHost.StartAsync();

            var loginWindow = AppHost.Services.GetRequiredService<LoginWindow>();
            var ok = loginWindow.ShowDialog();

            if (ok != true)
            {
                Shutdown();
                return;
            }

            var mainWindow = AppHost.Services.GetRequiredService<MainWindow>();
            Current.MainWindow = mainWindow;
            mainWindow.Show();
            mainWindow.Activate();

            var nav = AppHost.Services.GetRequiredService<INavigationService>();
            nav.NavigateTo<WelcomeViewModel>();

            // Maintenant, on peut laisser WPF fermer l'app quand MainWindow se ferme
            ShutdownMode = ShutdownMode.OnMainWindowClose;
        }

    }
}
