﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Rditil.Models
{
    public class ExamAttempt
    {
        public int ExamenId { get; set; }
        public Examen Examen { get; set; } = null!;

        public ICollection<ExamAnswer> Answers { get; set; } = new List<ExamAnswer>();

        [Key]
        public int Id_ExamAttempt { get; set; }

        public int Id_Utilisateur { get; set; }
        public DateTime StartedAt { get; set; } = DateTime.UtcNow;
        public DateTime? FinishedAt { get; set; }

        public int Score { get; set; }

        [NotMapped]
        public int Total => TotalQuestions;
        public int TotalQuestions { get; set; } = 40;

        // Navigation (si tu as Utilisateur)
        public Utilisateur? Utilisateur { get; set; }
        public string UserFullName { get; internal set; }
    }
}
