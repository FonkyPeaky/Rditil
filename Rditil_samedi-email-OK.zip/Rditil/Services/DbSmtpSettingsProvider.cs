﻿using Microsoft.EntityFrameworkCore;
using Rditil.Data;
using System.Linq;
using System.Threading.Tasks;

namespace Rditil.Services
{
    public class DbSmtpSettingsProvider : ISmtpSettingsProvider
    {
        private readonly IDbContextFactory<AppDbContext> _dbFactory;

        public DbSmtpSettingsProvider(IDbContextFactory<AppDbContext> dbFactory)
        {
            _dbFactory = dbFactory;
        }

        public async Task<SmtpSettings?> GetActiveAsync()
        {
            await using var db = await _dbFactory.CreateDbContextAsync();

            // Requête : dernier SMTP activé
            var q = db.SmtpSettings
                .AsNoTracking()
                .Where(x => x.Enabled)
                .OrderByDescending(x => x.UpdatedAt);

            // Debug (optionnel) : affiche la requête générée par EF
            System.Diagnostics.Debug.WriteLine(q.ToQueryString());

            var row = await q.FirstOrDefaultAsync();
            if (row == null) return null;

            return new SmtpSettings
            {
                Enabled = row.Enabled,
                Host = row.Host,
                Port = row.Port,
                UseSsl = false,               // Outlook : plutôt StartTLS
                UseStartTls = row.UseStartTls,
                Username = row.Username,
                Password = row.Password,
                FromEmail = row.FromEmail,
                FromName = "RDITIL"
            };
        }
    }
}
