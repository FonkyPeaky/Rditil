﻿using System.Threading.Tasks;
using Rditil.Services;


namespace Rditil.Services
{
    public interface ISmtpSettingsProvider
    {
        Task<SmtpSettings?> GetActiveAsync();
    }
}
