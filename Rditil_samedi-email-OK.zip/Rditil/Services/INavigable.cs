using System.Collections.Generic;

namespace Rditil.Services
{
    public interface INavigable
    {
        /// <summary>
        /// Called by the navigation service after the ViewModel is set as DataContext.
        /// Parameters can be null.
        /// </summary>
        void OnNavigatedTo(Dictionary<string, object?>? parameters);
    }
}

