using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Rditil.Models;

namespace Rditil.Services
{
    public interface IEmailService
    {
        Task SendExamReportAsync(
            string to,
            string? cc,
            string subject,
            string userFullName,
            int score,
            int total,
            TimeSpan duration,
            IReadOnlyList<ExamReportRow> rows
        );
    }
}
