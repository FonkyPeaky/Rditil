﻿using System.Windows.Controls;
using Rditil.ViewModels;

namespace Rditil.Views
{
    public partial class QuestionPage : Page
    {
        public QuestionPage()
        {
            InitializeComponent();
        }

        private async void Page_Loaded(object sender, System.Windows.RoutedEventArgs e)
        {
            if (DataContext is ExamViewModel vm)
                await vm.EnsureLoadedAsync();
        }
    }
}
