﻿using Rditil.ViewModels;
using System.Windows;
using System.Windows.Controls;

namespace Rditil.Views
{
    public partial class ExamenView : Page
    {
        public ExamenView(ExamViewModel vm)
        {
            InitializeComponent();
            // DataContext est défini ici pour que NavigationService réutilise la même instance.
            DataContext = vm;
        }
    }
}
