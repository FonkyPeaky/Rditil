﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace Rditil.Views
{
    public partial class WelcomePage : Page
    {
        public WelcomePage()
        {
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            if (Resources["EnterStoryboard"] is Storyboard sb)                                                    
                sb.Begin();
        }
        private void Card_Loaded(object sender, RoutedEventArgs e)
        {
            var sb = (Storyboard)FindResource("FadeSlideIn");
            sb.Begin((FrameworkElement)sender);
        }

    }
}
