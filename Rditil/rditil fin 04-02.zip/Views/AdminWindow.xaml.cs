using System;
using System.Windows;
using Rditil.Services;

namespace Rditil.Views
{
    public partial class AdminWindow : Window
    {
        private readonly IServiceProvider _sp;

        public AdminWindow(IServiceProvider sp)
        {
            InitializeComponent();
            _sp = sp;
        }

        public void NavigateToAdminPanel()
        {
            // Resolve the admin panel page via DI so it gets its ViewModel.
            var page = (AdminPanel)_sp.GetService(typeof(AdminPanel))!;
            RootFrame.Navigate(page);
        }
    }
}
