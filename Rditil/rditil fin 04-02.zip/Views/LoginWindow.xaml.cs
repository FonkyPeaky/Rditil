using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Rditil.ViewModels;
using System;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;

namespace Rditil.Views
{
    public partial class LoginWindow : Window
    {
        private readonly LoginViewModel _vm;
        private readonly IServiceProvider _services;
        private readonly IConfiguration _config;

        // Brushes for error states
        private readonly SolidColorBrush _errorBrush = new SolidColorBrush(Color.FromRgb(220, 38, 38)); // #DC2626
        private readonly SolidColorBrush _normalBrush = new SolidColorBrush(Color.FromRgb(224, 231, 255)); // #E0E7FF

        public LoginWindow(LoginViewModel vm, IServiceProvider services, IConfiguration config)
        {
            InitializeComponent();

            _vm = vm;
            _services = services;
            _config = config;

            DataContext = _vm;
            PreviewKeyDown += LoginWindow_PreviewKeyDown;

            _vm.PropertyChanged += Vm_PropertyChanged;

            _vm.LoginSucceeded += () =>
            {
                DialogResult = true;
                Close();
            };
        }

        // ✅ Helper robuste: évite les CS0103 même si les champs XAML ne sont pas générés
        private T? UI<T>(string name) where T : class => FindName(name) as T;

        private void Vm_PropertyChanged(object? sender, PropertyChangedEventArgs e)
        {
            if (e.PropertyName == nameof(LoginViewModel.ErrorMessage))
                UpdateErrorDisplay();
        }

        private void UpdateErrorDisplay()
        {
            var hasError = !string.IsNullOrEmpty(_vm.ErrorMessage);

            var errorBorder = UI<Border>("ErrorBorder");
            var loginCard = UI<Border>("LoginCard");
            var emailBox = UI<TextBox>("EmailBox");
            var pwdBox = UI<PasswordBox>("PwdBox");

            // Show/hide error border with animation
            if (errorBorder != null)
                errorBorder.Visibility = hasError ? Visibility.Visible : Visibility.Collapsed;

            // Shake animation for error feedback
            if (hasError && loginCard != null)
            {
                var shakeAnim = new DoubleAnimation
                {
                    From = -5,
                    To = 5,
                    Duration = TimeSpan.FromMilliseconds(50),
                    AutoReverse = true,
                    RepeatBehavior = new RepeatBehavior(3)
                };

                shakeAnim.Completed += (s, e) =>
                {
                    loginCard.RenderTransform = new TranslateTransform(0, 0);
                };

                loginCard.RenderTransform = new TranslateTransform();
                loginCard.RenderTransform.BeginAnimation(TranslateTransform.XProperty, shakeAnim);
            }

            // Apply red border to inputs when there's an error
            if (emailBox != null)
                emailBox.BorderBrush = hasError ? _errorBrush : _normalBrush;

            if (pwdBox != null)
                pwdBox.BorderBrush = hasError ? _errorBrush : _normalBrush;
        }

        private void ClearErrorState()
        {
            if (!string.IsNullOrEmpty(_vm.ErrorMessage))
                _vm.ErrorMessage = string.Empty;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            if (Resources["WindowFadeIn"] is Storyboard windowFadeIn) windowFadeIn.Begin();
            if (Resources["LeftPanelSlideIn"] is Storyboard leftPanel) leftPanel.Begin();
            if (Resources["LoginCardSlideIn"] is Storyboard loginCard) loginCard.Begin();
            if (Resources["BrandingFadeIn"] is Storyboard branding) branding.Begin();

            if (Resources["OrbFloat1"] is Storyboard orb1) orb1.Begin();
            if (Resources["OrbFloat2"] is Storyboard orb2) orb2.Begin();
            if (Resources["OrbFloat3"] is Storyboard orb3) orb3.Begin();
            if (Resources["LogoPulse"] is Storyboard logoPulse) logoPulse.Begin();
        }

        private void LoginWindow_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            // Raccourci caché : Ctrl + Shift + A
            if (e.Key == Key.A && Keyboard.Modifiers.HasFlag(ModifierKeys.Control) && Keyboard.Modifiers.HasFlag(ModifierKeys.Shift))
            {
                e.Handled = true;
                OpenAdminFlow();
            }
        }

        private void TopBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ButtonState == MouseButtonState.Pressed)
                DragMove();
        }

        private void Close_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }

        private void PwdBox_PasswordChanged(object sender, RoutedEventArgs e)
        {
            if (DataContext is LoginViewModel vm && sender is PasswordBox pb)
            {
                vm.Password = pb.Password;
                ClearErrorState();
            }
        }

        private void EmailBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            ClearErrorState();
        }

        private void OpenAdmin_Click(object sender, RoutedEventArgs e) => OpenAdminFlow();

        private void OpenAdminFlow()
        {
            try
            {
                var pin = _config["Admin:Pin"] ?? "2710";
                var maxAttempts = int.TryParse(_config["Admin:MaxAttempts"], out var ma) ? ma : 3;
                var lockoutSeconds = int.TryParse(_config["Admin:LockoutSeconds"], out var ls) ? ls : 60;

                var dlg = new PinDialog(pin, maxAttempts, lockoutSeconds) { Owner = this };
                var ok = dlg.ShowDialog();
                if (ok != true) return;

                var adminWindow = _services.GetRequiredService<AdminPanelWindow>();
                adminWindow.Owner = this;
                adminWindow.ShowDialog();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Impossible d’ouvrir l’AdminPanel : {ex.Message}", "Erreur", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
