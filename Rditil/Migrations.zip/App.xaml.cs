﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Rditil.Data;
using Rditil.Services;
using Rditil.ViewModels;
using System;
using System.IO;
using System.Windows;

namespace Rditil
{
    public partial class App : Application
    {
        public static IHost AppHost { get; private set; } = null!;

        public App()
        {
            AppHost = Host.CreateDefaultBuilder()
                .ConfigureAppConfiguration((context, config) =>
                {
                    config.SetBasePath(Directory.GetCurrentDirectory());
                    config.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
                })
                .ConfigureServices((context, services) =>
                {
                    // CONFIG
                    services.Configure<SmtpSettings>(context.Configuration.GetSection("Smtp"));

                    // DB (si tu utilises AppDbContextFactory, garde ton code actuel ici)
                    services.AddSingleton<AppDbContextFactory>();

                    // SERVICES
                    services.AddSingleton<IEmailService, EmailService>();
                    services.AddSingleton<INavigationService, NavigationService>();

                    // VIEWMODELS (exemples)
                    services.AddTransient<WelcomeViewModel>();
                    services.AddTransient<LoginViewModel>();
                    services.AddTransient<ExamViewModel>();
                    services.AddTransient<EndPageViewModel>();

                    // WINDOWS / MAIN
                    services.AddSingleton<MainWindow>();
                })
                .Build();
        }

        protected override async void OnStartup(StartupEventArgs e)
        {
            await AppHost.StartAsync();

            var mainWindow = AppHost.Services.GetRequiredService<MainWindow>();
            Current.MainWindow = mainWindow;
            mainWindow.Show();

            base.OnStartup(e);
        }

        protected override async void OnExit(ExitEventArgs e)
        {
            if (AppHost != null)
                await AppHost.StopAsync();

            base.OnExit(e);
        }
    }
}
