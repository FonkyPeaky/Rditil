﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rditil.Models
{
    public class ExamReportRow
    {
        public int Numero { get; set; }
        public string Question { get; set; } = "";
        public string ReponseChoisie { get; set; } = "";
        public string BonneReponse { get; set; } = "";
        public bool EstCorrect { get; set; }
    }
}
