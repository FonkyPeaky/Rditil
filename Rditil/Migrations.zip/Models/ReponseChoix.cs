using CommunityToolkit.Mvvm.ComponentModel;

namespace Rditil.Models
{
    /// <summary>
    /// Modèle "UI" pour afficher une réponse possible à cocher.
    /// </summary>
    public partial class ReponseChoix : ObservableObject
    {
        public int Id { get; set; }

        /// <summary>
        /// Texte affiché dans l'UI.
        /// </summary>
        public string Text { get; set; } = string.Empty;

        /// <summary>
        /// Vrai si cette réponse est correcte (corrigé).
        /// </summary>
        public bool EstCorrect { get; set; }

        /// <summary>
        /// Vrai si l'utilisateur a sélectionné cette réponse.
        /// </summary>
        [ObservableProperty]
        private bool isSelected;
    }
}
