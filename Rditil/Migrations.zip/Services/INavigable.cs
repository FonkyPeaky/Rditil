using System.Collections.Generic;

namespace Rditil.Services
{
    /// <summary>
    /// Simple hook called by NavigationService when the ViewModel is shown.
    /// 
    /// NOTE: kept as void to avoid a big refactor of the navigation stack.
    /// If you need async work, implement it as async void but make sure you don't
    /// reuse the same DbContext for multiple concurrent operations.
    /// </summary>
    public interface INavigable
    {
        void OnNavigatedTo(Dictionary<string, object?>? parameters = null);
    }
}
