using MailKit.Net.Smtp;
using Microsoft.Extensions.Options;
using MimeKit;
using Rditil.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Rditil.Services
{
    public class EmailService : IEmailService
    {
        private readonly SmtpSettings _smtp;

        public EmailService(IOptions<SmtpSettings> smtpOptions)
        {
            _smtp = smtpOptions.Value;
        }

        public async Task SendExamReportAsync(
            string to,
            string userFullName,
            int score,
            int total,
            TimeSpan duration,
            IEnumerable<ExamReportRow> rows)
        {
            var message = new MimeMessage();
            message.From.Add(new MailboxAddress(_smtp.FromName ?? "RDITIL", _smtp.FromEmail));
            message.To.Add(MailboxAddress.Parse(to));
            message.Subject = $"RDITIL - Résultat examen blanc - {userFullName} ({score}/{total})";

            var html = BuildHtml(userFullName, score, total, duration, rows);
            message.Body = new BodyBuilder { HtmlBody = html }.ToMessageBody();

            using var client = new SmtpClient();
            await client.ConnectAsync(_smtp.Host, _smtp.Port, _smtp.UseSsl);

            if (!string.IsNullOrWhiteSpace(_smtp.Username))
                await client.AuthenticateAsync(_smtp.Username, _smtp.Password);

            await client.SendAsync(message);
            await client.DisconnectAsync(true);
        }

        private static string BuildHtml(string userFullName, int score, int total, TimeSpan duration, IEnumerable<ExamReportRow> rows)
        {
            var safeName = System.Net.WebUtility.HtmlEncode(userFullName);
            var safeDuration = System.Net.WebUtility.HtmlEncode(duration.ToString(@"hh\:mm\:ss"));

            var lines = rows.Select(r =>
            {
                var q = System.Net.WebUtility.HtmlEncode(r.Enonce);
                var chosen = System.Net.WebUtility.HtmlEncode(r.ChosenText);
                var ok = r.IsCorrect ? "✅" : "❌";
                return $"<tr><td>{q}</td><td>{chosen}</td><td style='text-align:center'>{ok}</td></tr>";
            });

            return $@"
<!doctype html>
<html>
<head><meta charset='utf-8'></head>
<body style='font-family:Segoe UI, Arial;'>
  <h2>Résultat examen blanc</h2>
  <p><b>Candidat :</b> {safeName}</p>
  <p><b>Score :</b> {score}/{total}</p>
  <p><b>Durée :</b> {safeDuration}</p>

  <h3>Détail des réponses</h3>
  <table border='1' cellspacing='0' cellpadding='8' style='border-collapse:collapse; width:100%'>
    <thead>
      <tr style='background:#f2f6ff'>
        <th>Question</th>
        <th>Réponse choisie</th>
        <th>OK</th>
      </tr>
    </thead>
    <tbody>
      {string.Join("", lines)}
    </tbody>
  </table>
</body>
</html>";
        }
    }
}
