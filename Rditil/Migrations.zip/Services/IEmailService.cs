﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Rditil.Models;

namespace Rditil.Services
{
    public interface IEmailService
    {
        Task SendExamReportAsync(
            string to,
            string userFullName,
            int score,
            int total,
            TimeSpan duration,
            IEnumerable<ExamReportRow> rows
        );
    }
}
