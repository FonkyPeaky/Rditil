﻿using CommunityToolkit.Mvvm.ComponentModel;
using Rditil.Models;
using Rditil.Services;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;

namespace Rditil.ViewModels
{
    public class EndPageViewModel : ObservableObject
    {
        private readonly IEmailService _emailService;

        public EndPageViewModel(IEmailService emailService)
        {
            _emailService = emailService;

            SendToManagerCommand = new RelayCommand(async _ => await SendToManagerAsync(), _ => CanSend);
            BackHomeCommand = new RelayCommand(_ => BackHome?.Invoke(), _ => true);
        }

        // UI
        public string Title => "Félicitations";
        public int Score { get; set; }
        public int Total { get; set; } = 40;
        public string UserFullName { get; set; } = "Test";
        public string ManagerEmail { get; set; } = "manager@exemple.com";
        public TimeSpan Duration { get; set; } = TimeSpan.FromMinutes(60);

        public ObservableCollection<ExamReportRow> Rows { get; } = new();

        private bool _isSending;
        public bool IsSending
        {
            get => _isSending;
            set { _isSending = value; OnPropertyChanged(); OnPropertyChanged(nameof(CanSend)); }
        }

        public bool CanSend => !IsSending && !string.IsNullOrWhiteSpace(ManagerEmail) && Rows.Count > 0;

        public RelayCommand SendToManagerCommand { get; }
        public RelayCommand BackHomeCommand { get; }

        public Action? BackHome { get; set; }

        public void Load(int score, int total, string userFullName, string managerEmail, TimeSpan duration, IEnumerable<ExamReportRow> rows)
        {
            Score = score;
            Total = total;
            UserFullName = userFullName;
            ManagerEmail = managerEmail;
            Duration = duration;

            Rows.Clear();
            foreach (var r in rows)
                Rows.Add(r);

            OnPropertyChanged(nameof(Score));
            OnPropertyChanged(nameof(Total));
            OnPropertyChanged(nameof(UserFullName));
            OnPropertyChanged(nameof(ManagerEmail));
            OnPropertyChanged(nameof(Duration));

            SendToManagerCommand.RaiseCanExecuteChanged();
        }

        private async Task SendToManagerAsync()
        {
            try
            {
                IsSending = true;
                SendToManagerCommand.RaiseCanExecuteChanged();

                await _emailService.SendExamReportAsync(
                    to: ManagerEmail,
                    userFullName: UserFullName,
                    score: Score,
                    total: Total,
                    duration: Duration,
                    rows: Rows.ToList()
                );
            }
            finally
            {
                IsSending = false;
                SendToManagerCommand.RaiseCanExecuteChanged();
            }
        }
    }
}
