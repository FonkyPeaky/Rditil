using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.EntityFrameworkCore;
using Rditil.Data;
using Rditil.Models;
using Rditil.Services;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using System.Collections.Generic;
using System.Linq;

namespace Rditil.ViewModels
{
    public partial class ExamViewModel : ObservableObject, INavigable
    {
        private readonly AppDbContext _ctx;
        private readonly DispatcherTimer _timer;
        private readonly List<ExamReportRow> _reportRows = new();


        private readonly int _questionCount = 40;
        private readonly TimeSpan _duration = TimeSpan.FromHours(1);

        private int _index;
        private int _score;
        private Question[] _questions = Array.Empty<Question>();
        private TimeSpan _remaining;

        public ExamViewModel(AppDbContext ctx)
        {
            _ctx = ctx;

            ReponsesChoix = new ObservableCollection<ReponseChoix>();

            ToggleChoiceCommand = new RelayCommand<ReponseChoix?>(ToggleChoice);
            QuestionSuivanteCommand = new AsyncRelayCommand(QuestionSuivanteAsync, CanGoNext);

            _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
            _timer.Tick += (_, __) => Tick();

            // Valeurs par défaut (pour design-time / éviter null)
            QuestionHeaderText = "Question 0/0";
            TempsRestantText = _duration.ToString(@"hh\:mm\:ss");
        }

        public ObservableCollection<ReponseChoix> ReponsesChoix { get; }

        [ObservableProperty]
        private Question? questionEnCours;

        [ObservableProperty]
        private string questionHeaderText = string.Empty;

        [ObservableProperty]
        private string tempsRestantText = string.Empty;

        [ObservableProperty]
        private bool isLoading;

        public IRelayCommand<ReponseChoix?> ToggleChoiceCommand { get; }
        public IAsyncRelayCommand QuestionSuivanteCommand { get; }

        public async void OnNavigatedTo(System.Collections.Generic.Dictionary<string, object?>? parameters = null)
        {
            try
            {
                IsLoading = true;
                _timer.Stop();

                _index = 0;
                _score = 0;
                _remaining = _duration;
                TempsRestantText = _remaining.ToString(@"hh\:mm\:ss");

                // IMPORTANT: une seule requête, pas de concurrence.
                var all = await _ctx.Questions
                    .AsNoTracking()
                    .Include(q => q.Reponses)
                    .Where(q => q.Enonce != null && q.Enonce != "")
                    .ToListAsync();

                // Random + take
                _questions = all
                    .OrderBy(_ => Guid.NewGuid())
                    .Take(_questionCount)
                    .ToArray();

                if (_questions.Length == 0)
                {
                    MessageBox.Show("Aucune question trouvée en base (table Questions).", "RDITIL", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                ChargerQuestion();
                _timer.Start();
            }
            finally
            {
                IsLoading = false;
                QuestionSuivanteCommand.NotifyCanExecuteChanged();
            }
        }

        private void Tick()
        {
            if (IsLoading) return;

            _remaining = _remaining - TimeSpan.FromSeconds(1);
            if (_remaining < TimeSpan.Zero) _remaining = TimeSpan.Zero;

            TempsRestantText = _remaining.ToString(@"hh\:mm\:ss");

            if (_remaining == TimeSpan.Zero)
            {
                _timer.Stop();
                FinishExam();
            }
        }

        private void ChargerQuestion()
        {
            if (_index < 0 || _index >= _questions.Length)
            {
                FinishExam();
                return;
            }

            QuestionEnCours = _questions[_index];
            QuestionHeaderText = $"Question {_index + 1}/{_questions.Length}";

            ReponsesChoix.Clear();

            foreach (var r in QuestionEnCours.Reponses.OrderBy(_ => Guid.NewGuid()))
            {
                ReponsesChoix.Add(new ReponseChoix
                {
                    Id = r.Id_Reponse,
                    Text = r.TextReponse ?? string.Empty,
                    EstCorrect = r.EstCorrect,
                    IsSelected = false
                });
            }

            QuestionSuivanteCommand.NotifyCanExecuteChanged();
        }

        private void ToggleChoice(ReponseChoix? choice)
        {
            if (choice == null) return;

            // 1 seule réponse (mode radio)
            foreach (var c in ReponsesChoix)
            {
                if (!ReferenceEquals(c, choice))
                    c.IsSelected = false;
            }

            // si elle est cochée -> on garde; si décochée -> rien
            QuestionSuivanteCommand.NotifyCanExecuteChanged();
        }

        private bool CanGoNext()
        {
            return !IsLoading && ReponsesChoix.Any(c => c.IsSelected);
        }

        private async Task QuestionSuivanteAsync()
        {
            var selected = ReponsesChoix.FirstOrDefault(r => r.IsSelected);
            var chosenText = selected?.Text ?? "";
            var goodText = ReponsesChoix.FirstOrDefault(r => r.EstCorrect)?.Text ?? "";
            var ok = selected?.EstCorrect == true;

            _reportRows.Add(new ExamReportRow
            {
                Numero = _index + 1,
                Question = QuestionEnCours?.Enonce ?? "",
                ReponseChoisie = chosenText,
                BonneReponse = goodText,
                EstCorrect = ok
            });

            if (IsLoading) return;

            //var selected = ReponsesChoix.FirstOrDefault(c => c.IsSelected);
            if (selected == null) return;

            if (selected.EstCorrect)
                _score++;

            _index++;

            if (_index >= _questions.Length)
            {
                FinishExam();
                return;
            }

            ChargerQuestion();
            await Task.CompletedTask;
        }

        private void FinishExam()
        {
            _timer.Stop();

            var total = _questions?.Count ?? 0;
            var duration = TimeSpan.FromHours(1) - _remaining;
            if (duration < TimeSpan.Zero) duration = TimeSpan.FromHours(1);

            var rows = new List<ExamReportRow>();

            for (int i = 0; i < total; i++)
            {
                var q = _questions[i];

                // La bonne réponse (corrigé)
                var good = q.Reponses?.FirstOrDefault(r => r.EstCorrect)?.TextReponse ?? "";
            }

            var parameters = new Dictionary<string, object?>
            {
                ["Score"] = _score,
                ["Total"] = total,
                ["Duration"] = duration,
                ["UserFullName"] = App.CurrentUserFullName,
                ["ManagerEmail"] = App.ManagerEmail
                // ["Rows"] = rows  // on l’ajoute après la petite modif ci-dessous
            };
            parameters["Rows"] = _reportRows;


            _navigation.NavigateTo<EndPageViewModel>(parameters);
        }
    }
}
