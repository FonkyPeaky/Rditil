using System.Windows.Controls;

namespace Rditil.Views
{
    public partial class ProgressPage : Page
    {
        public ProgressPage()
        {
            InitializeComponent();
        }
    }
}
