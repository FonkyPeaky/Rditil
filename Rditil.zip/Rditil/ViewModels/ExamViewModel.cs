using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.EntityFrameworkCore;
using Rditil.Data;
using Rditil.Models;
using Rditil.Services;
using Rditil.Views;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using Timer = System.Timers.Timer;

namespace Rditil.ViewModels
{
    public partial class ExamViewModel : ObservableObject
    {
        private readonly AppDbContext _ctx;
        private readonly IEmailService _emailService;
        private readonly string _managerEmail;
        private readonly string _userEmail;
        public string? UserFullName { get; set; }


        private readonly Timer _timer;
        private TimeSpan _tempsRestant = TimeSpan.FromHours(1);

        [ObservableProperty] private string _tempsRestantText = "01:00:00";
        [ObservableProperty] private Question _questionEnCours = null!;
        [ObservableProperty] private ObservableCollection<ReponseChoix> _reponsesChoix = new();

        private List<Question> _questionsTirees = new();
        private int _index = 0;
        private int _score = 0;

        public IAsyncRelayCommand DemarrerExamenCommand { get; }
        public IAsyncRelayCommand QuestionSuivanteCommand { get; }

        public ExamViewModel(AppDbContext ctx, IEmailService emailService, string userEmail, string managerEmail)
        {
            _ctx = ctx;
            _emailService = emailService;
            _userEmail = userEmail;
            _managerEmail = managerEmail;

            DemarrerExamenCommand = new AsyncRelayCommand(DemarrerExamenAsync);
            QuestionSuivanteCommand = new AsyncRelayCommand(ValiderEtSuivantAsync);

            _timer = new Timer(1000);
            _timer.Elapsed += (_, __) =>
            {
                _tempsRestant = _tempsRestant.Subtract(TimeSpan.FromSeconds(1));
                TempsRestantText = _tempsRestant.ToString();
                if (_tempsRestant <= TimeSpan.Zero)
                {
                    _timer.Stop();
                    Application.Current.Dispatcher.Invoke(async () => await FinirExamenAsync());
                }
            };
        }

        private async Task DemarrerExamenAsync()
        {
            // Tirer 40 questions aléatoires
            var all = await _ctx.Questions.Include(q => q.Reponses).ToListAsync();
            _questionsTirees = all.OrderBy(_ => Guid.NewGuid()).Take(40).ToList();
            _index = 0;
            _score = 0;
            _tempsRestant = TimeSpan.FromHours(1);
            TempsRestantText = _tempsRestant.ToString();

            ChargerQuestion(_index);
            _timer.Start();
        }

        private void ChargerQuestion(int index)
        {
            if (index < 0 || index >= _questionsTirees.Count) return;
            QuestionEnCours = _questionsTirees[index];

            var reps = QuestionEnCours.Reponses
                .Select(r => new ReponseChoix
                {
                    Id = r.Id_Reponse,
                    TextReponse = r.TextReponse ?? string.Empty,
                    EstCorrect = r.EstCorrect,
                    // IsChoisie par défaut false
                })
                .OrderBy(_ => Guid.NewGuid()) // mélanger l'ordre des réponses
                .ToList();

            ReponsesChoix = new ObservableCollection<ReponseChoix>(reps);
        }

        private async Task ValiderEtSuivantAsync()
        {
            // Corrige la question courante : set choisi == set correct
            var selectedIds = ReponsesChoix.Where(x => x.IsChoisie).Select(x => x.Id).ToHashSet();
            var correctIds = ReponsesChoix.Where(x => x.EstCorrect).Select(x => x.Id).ToHashSet();
            if (selectedIds.SetEquals(correctIds))
                _score++;

            _index++;
            if (_index < _questionsTirees.Count)
            {
                ChargerQuestion(_index);
            }
            else
            {
                _timer.Stop();
                await FinirExamenAsync();
            }
        }

        private async Task FinirExamenAsync()
        {
            try
            {
                await _emailService.SendExamResultAsync(_managerEmail, _userEmail, _score, _questionsTirees.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Échec d'envoi de l'email: {ex.Message}", "Email", MessageBoxButton.OK, MessageBoxImage.Warning);
            }

            // Naviguer vers une page de fin simple (si EndPage est une Window, on peut l'ouvrir)
            var end = new EndPage(new ResultViewModel(_emailService, _userEmail, _score, _questionsTirees.Count));
            end.Show();
            Application.Current.Windows.OfType<Window>().FirstOrDefault(w => w is Views.ExamenView)?.Close();
        }
    }
}
