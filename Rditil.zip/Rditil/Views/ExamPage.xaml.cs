﻿using System.Windows;

namespace Rditil.Views
{
    public partial class ExamPage : Window
    {
        public ExamPage()
        {
            InitializeComponent();
        }
    }
}
