﻿using System.Windows;
using System.Windows.Media.Animation;
using Microsoft.Extensions.DependencyInjection;
using Rditil.Data;
using Rditil.Services;
using Rditil.ViewModels;

namespace Rditil.Views
{
    public partial class ExamenView
    {
        public ExamenView(string userEmail, string managerEmail, string userFullName = null)
        {
            InitializeComponent();

            if (Resources["EnterStoryboard"] is Storyboard sb)
                sb.Begin();

            // ✅ récup DI via App
            var sp = ((App)Application.Current).Services;        // ou: App.AppHost.Services
            var ctx = sp.GetRequiredService<AppDbContext>();
            var mail = sp.GetRequiredService<IEmailService>();

            var vm = new ExamViewModel(ctx, mail, userEmail, managerEmail)
            {
                UserFullName = userFullName
            };

            DataContext = vm;
        }
    }
}
